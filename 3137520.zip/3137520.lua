addappid(3137520)
addappid(3137521, 1, "6dffa7bebdc89d2a49f94564b961d8de4b0254b0c58e9e52f218f57059b02de2")
setManifestid(3137521, "6130998764318305876", 0)



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
