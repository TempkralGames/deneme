-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(1032430)
addappid(1032431, 1, "e533393d2895e4516e079d4b23cd2d771cbf53adbe1954e629fdc0ae0689f62d")
setManifestid(1032431, "4008090271247957884", 0)