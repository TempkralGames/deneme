addappid(1928690)
addappid(1928691, 1, "5cd51e7d45f7b58876274ad752d66d96a9320abfbbe7230fa5daa34115656679")
setManifestid(1928691, "1391217765722460969", 0)




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]