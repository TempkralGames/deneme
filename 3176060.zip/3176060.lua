-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(3176060)
addappid(228989)
addappid(228990)
setManifestid(228990,"1829726630299308803")
addappid(3176061,0,"87ccd43a7ff83224384228a50111bc6cfee10144e93af2284c27dcdae12d5e38")
setManifestid(3176061,"8934458582853199597")