addappid(1479730)
addappid(1479731, 1, "64205c91ebfac38afeb2011798b9270dc5d1eec20ef0d4b176a42fbf5570de84")
setManifestid(1479731, "9168612380686654993", 0)
addappid(3565060, 1, "25969d0cfdf09a97590616156414c9996ebf94afe209ed4cb0eb957fa79a2c77")
setManifestid(3565060, "3073898408723519129", 0)


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
