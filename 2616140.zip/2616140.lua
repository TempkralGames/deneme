addappid(2616140)
addappid(2616141,0,"ef52715a1a30dd7b951c862bae4ab7c50394aef7a3635d8ba058e97db3873dbc")
setManifestid(2616141,"660077157210307943")


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]