addappid(1486920)
addappid(3478280)
addappid(1486921,0,"26528db8fe19a223ddd4dbc280b52006e6b4aad5884ce084762e313c91d0de46")
setManifestid(1486921,"4776977188543296732")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]