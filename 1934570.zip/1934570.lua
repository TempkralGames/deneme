addappid(1934570)
addappid(1934571, 1, "8339de2d0121af2b4b3a7ec0b461091ae5a3dcfb4f531c1d45aa3640a8715d17")
setManifestid(1934571, "5337233137981951955", 0)
addappid(3558811, 1, "678be8b914133c73b665cea06ab2d2e9d208b0eba0f9e2d06312353dc31d1b0b")
setManifestid(3558811, "8820380893997423567", 0)
addappid(3558812, 1, "f631398c880fb244d758adc51880b4fb9d4f0f86fef45923385963ee0d3c5ca7")
setManifestid(3558812, "69876713511591725", 0)
addappid(3558820, 1, "ab5ed1844b76e916ea4ee72419ba812c40aa5ee6454c80c008ce407bbb6c3787")
setManifestid(3558820, "2431488219338558653", 0)


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
