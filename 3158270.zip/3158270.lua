addappid(3158270)
addappid(3158271,0,"ac1bf1ba8de713dc13d490e06bb72281575f7214229629432aabe5bd27fc85f2")
setManifestid(3158271,"2008489641104960312")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]