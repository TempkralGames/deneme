addappid(1374490)
addappid(1374491,1,"e1a3b5ad6a0fbda32b1fceadce8be5fe365e6c98dcc654bfdef62b6aa01f48d5")
setManifestid(1374491,"508519357932239539",20463181718)
addappid(3501790)



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
