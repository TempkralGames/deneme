addappid(3453600)
addappid(3453601,0,"ce8d6b5c4d99db4329aa5baa99ef1de9422793b7c659c2d8474c46aea1e95b8b")
setManifestid(3453601,"6100509832675763607")


--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]