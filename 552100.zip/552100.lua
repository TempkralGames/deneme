-- manifest & lua provided by: https://www.piracybound.com/discord
-- via manilua
addappid(552100)
addappid(552101, 1, "2655dc8f6778dc013bae87f3f20881b6b118c6beaca59114be62b0dd6a551679")
setManifestid(552101, "6579074036481288258", 0)